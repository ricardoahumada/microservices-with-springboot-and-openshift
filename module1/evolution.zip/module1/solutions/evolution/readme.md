---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 30460221008887b1df54b0112d416c37268783efe9ecf288fd587c6fdb206af30e553707c3022100e4d9b62c4e5d440741a52d8e654168a14a8f2de489b4e4001ba582e248ba45b9
    ReservedCode2: 3045022100a0d0e7c3eae20dda74b65db8999a578a81fd13636d8c366cddaa1eaec53302110220094cb8ab37893a4dda571ed201a8673c42fd644099d02997e9ebb453706d099a
---

# Evolución: mutualidad-platform-base → mutualidad-platform

## Resumen

Esta carpeta contiene las clases necesarias para evolucionar el proyecto base hacia la versión completa con DDD.

```
mutualidad-platform-base/          →          mutualidad-platform/
(solo Application + HealthController)         (estructura DDD completa)
```

## Estructura de Evolución

```
evolution/
├── readme.md                      # Esta guía
├── afiliado-service/              # Clases para afiliado
│   ├── api/
│   ├── application/
│   ├── domain/
│   ├── infrastructure/
│   └── test/
├── beneficio-service/             # Clases para beneficio
│   ├── api/
│   ├── application/
│   ├── domain/
│   ├── infrastructure/
│   └── test/
├── notificacion-service/          # Clases para notificacion
│   ├── api/
│   ├── application/
│   ├── domain/
│   ├── infrastructure/
│   └── test/
└── validacion-service/            # Clases para validacion
    ├── api/
    ├── application/
    ├── domain/
    ├── infrastructure/
    └── test/
```

## Resumen de Clases por Servicio

| Servicio | Base | Completa | Clases a Añadir |
|----------|------|----------|-----------------|
| afiliado-service | 2 | 11 | 9 |
| beneficio-service | 2 | 12 | 10 |
| notificacion-service | 2 | 11 | 9 |
| validacion-service | 2 | 10 | 8 |

## Arquitectura DDD Aplicada

```
┌─────────────────────────────────────────────────────────────┐
│                      Servicio                                │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ api/                          (Adaptadores Entrada)  │   │
│  │  ├── controller/  → REST endpoints                   │   │
│  │  └── dto/         → Request/Response objects         │   │
│  └──────────────────────────────────────────────────────┘   │
│                            │                                 │
│                            ▼                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ application/              (Casos de Uso)             │   │
│  │  └── service/  → Orquestación de lógica              │   │
│  └──────────────────────────────────────────────────────┘   │
│                            │                                 │
│                            ▼                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ domain/                   (Núcleo del Negocio)       │   │
│  │  └── model/    → Entidades, Value Objects, Enums     │   │
│  └──────────────────────────────────────────────────────┘   │
│                            │                                 │
│                            ▼                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ infrastructure/           (Adaptadores Salida)       │   │
│  │  └── persistence/ → Repositorios JPA                 │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Orden de Implementación Recomendado

1. **domain/** - Primero las entidades y value objects
2. **infrastructure/** - Repositorios para persistir
3. **application/** - Servicios con lógica de negocio
4. **api/** - Controllers y DTOs para exponer funcionalidad
5. **test/** - Tests para verificar

## Guías por Servicio

- [afiliado-service/readme.md](afiliado-service/readme.md)
- [beneficio-service/readme.md](beneficio-service/readme.md)
- [notificacion-service/readme.md](notificacion-service/readme.md)
- [validacion-service/readme.md](validacion-service/readme.md)
