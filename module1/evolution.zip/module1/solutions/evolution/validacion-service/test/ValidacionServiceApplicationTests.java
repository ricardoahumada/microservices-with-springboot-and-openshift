package com.mutualidad.validacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidacionServiceApplicationTests {

    @Test
    void contextLoads() {
    }
}
