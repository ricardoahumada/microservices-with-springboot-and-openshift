---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304402205589ce5f2aa6c42b2c2806011205b88e2f4aba669d3dcdf776f6a3cb9415558a02206f21a3febec7bdda6dcbe43b3a76b224a69a22aac85ced2142a42c50cf7336e2
    ReservedCode2: 3045022057f1ae1d674f333c8ed50d618d47b883a9c43eb37dde138311cd09615662fceb022100a589959964a6ddf57869bd645f2de609584e4384320b08e8927bb8127eeae81e
---

# Evolución: validacion-service

## De mutualidad-platform-base a mutualidad-platform

### Estructura Base (2 clases)
```
validacion-service/
└── src/main/java/com/mutualidad/validacion/
    ├── ValidacionServiceApplication.java
    └── controller/
        └── HealthController.java
```

### Estructura Completa (10 clases)
```
validacion-service/
└── src/main/java/com/mutualidad/validacion/
    ├── ValidacionServiceApplication.java
    ├── api/
    │   ├── controller/
    │   │   └── ValidacionController.java
    │   └── dto/
    │       ├── ValidacionRequest.java
    │       └── ValidacionResponse.java
    ├── application/
    │   └── service/
    │       └── ValidacionService.java
    ├── domain/
    │   └── model/
    │       ├── ValidacionExterna.java
    │       ├── ResultadoValidacion.java
    │       └── TipoValidacion.java
    └── infrastructure/
        └── persistence/
            └── ValidacionExternaJpaRepository.java
```

---

## Clases a Añadir

### 1. domain/ (Modelos de Dominio)

| Clase | Descripción |
|-------|-------------|
| `ValidacionExterna.java` | Entidad para validaciones con sistemas externos |
| `ResultadoValidacion.java` | Enum: VALIDO, INVALIDO, PENDIENTE |
| `TipoValidacion.java` | Enum: DNI, EMAIL, TELEFONO, DIRECCION |

### 2. application/ (Servicios)

| Clase | Descripción |
|-------|-------------|
| `ValidacionService.java` | Lógica de validación de datos |

### 3. infrastructure/ (Persistencia)

| Clase | Descripción |
|-------|-------------|
| `ValidacionExternaJpaRepository.java` | Repositorio JPA |

### 4. api/ (Controladores y DTOs)

| Clase | Descripción |
|-------|-------------|
| `ValidacionController.java` | Endpoints REST |
| `ValidacionRequest.java` | DTO de entrada |
| `ValidacionResponse.java` | DTO de salida |

### 5. test/ (Tests)

| Clase | Descripción |
|-------|-------------|
| `ValidacionServiceApplicationTests.java` | Test de contexto |

---

## Pasos de Implementación

### Paso 1: Crear estructura de paquetes
```
mkdir -p src/main/java/com/mutualidad/validacion/{api/{controller,dto},application/service,domain/model,infrastructure/persistence}
mkdir -p src/test/java/com/mutualidad/validacion
```

### Paso 2: Copiar clases de domain/
Copiar: `ValidacionExterna.java`, `ResultadoValidacion.java`, `TipoValidacion.java`

### Paso 3: Copiar clases de infrastructure/
Copiar: `ValidacionExternaJpaRepository.java`

### Paso 4: Copiar clases de application/
Copiar: `ValidacionService.java`

### Paso 5: Copiar clases de api/
Copiar: `ValidacionController.java`, `ValidacionRequest.java`, `ValidacionResponse.java`

### Paso 6: Eliminar HealthController.java

---

## Verificación

```bash
cd validacion-service
mvn clean compile
mvn spring-boot:run
```

Probar endpoint:
```bash
curl -X POST http://localhost:8084/api/validaciones \
  -H "Content-Type: application/json" \
  -d '{"tipo": "DNI", "valor": "12345678A"}'
```
