---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 30440220659e7b1a72157892d82129ea9b343bf2cf0f100bac0614535e728baab714a38e0220660af61b91ba4cbe94a110075d18c497c41296217c39aa8d5dfa3f5b267337eb
    ReservedCode2: 304402205402a7bb4ab8a6beefa293b825d50ba1b82783cf7cb800f293f8599cdd2b93cb02203b2e7fbe1b7f1448c5e733630b4e770e63463362a2a0f6d19f72e17e9d31655e
---

# Evolución: notificacion-service

## De mutualidad-platform-base a mutualidad-platform

### Estructura Base (2 clases)
```
notificacion-service/
└── src/main/java/com/mutualidad/notificacion/
    ├── NotificacionServiceApplication.java
    └── controller/
        └── HealthController.java
```

### Estructura Completa (11 clases)
```
notificacion-service/
└── src/main/java/com/mutualidad/notificacion/
    ├── NotificacionServiceApplication.java
    ├── api/
    │   ├── controller/
    │   │   └── NotificacionController.java
    │   └── dto/
    │       ├── NotificacionRequest.java
    │       └── NotificacionResponse.java
    ├── application/
    │   └── service/
    │       └── NotificacionService.java
    ├── domain/
    │   └── model/
    │       ├── Notificacion.java
    │       ├── Destinatario.java
    │       ├── Canal.java
    │       └── EstadoNotificacion.java
    └── infrastructure/
        └── persistence/
            └── NotificacionJpaRepository.java
```

---

## Clases a Añadir

### 1. domain/ (Modelos de Dominio)

| Clase | Descripción |
|-------|-------------|
| `Notificacion.java` | Entidad principal con mensaje, canal, estado |
| `Destinatario.java` | Value Object con email, telefono |
| `Canal.java` | Enum: EMAIL, SMS, PUSH |
| `EstadoNotificacion.java` | Enum: PENDIENTE, ENVIADA, FALLIDA |

### 2. application/ (Servicios)

| Clase | Descripción |
|-------|-------------|
| `NotificacionService.java` | Lógica de envío de notificaciones |

### 3. infrastructure/ (Persistencia)

| Clase | Descripción |
|-------|-------------|
| `NotificacionJpaRepository.java` | Repositorio JPA |

### 4. api/ (Controladores y DTOs)

| Clase | Descripción |
|-------|-------------|
| `NotificacionController.java` | Endpoints REST |
| `NotificacionRequest.java` | DTO de entrada |
| `NotificacionResponse.java` | DTO de salida |

### 5. test/ (Tests)

| Clase | Descripción |
|-------|-------------|
| `NotificacionServiceApplicationTests.java` | Test de contexto |

---

## Pasos de Implementación

### Paso 1: Crear estructura de paquetes
```
mkdir -p src/main/java/com/mutualidad/notificacion/{api/{controller,dto},application/service,domain/model,infrastructure/persistence}
mkdir -p src/test/java/com/mutualidad/notificacion
```

### Paso 2: Copiar clases de domain/
Copiar: `Notificacion.java`, `Destinatario.java`, `Canal.java`, `EstadoNotificacion.java`

### Paso 3: Copiar clases de infrastructure/
Copiar: `NotificacionJpaRepository.java`

### Paso 4: Copiar clases de application/
Copiar: `NotificacionService.java`

### Paso 5: Copiar clases de api/
Copiar: `NotificacionController.java`, `NotificacionRequest.java`, `NotificacionResponse.java`

### Paso 6: Eliminar HealthController.java

---

## Verificación

```bash
cd notificacion-service
mvn clean compile
mvn spring-boot:run
```

Probar endpoint:
```bash
curl http://localhost:8083/api/notificaciones
```
