package com.mutualidad.afiliado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AfiliadoServiceApplicationTests {

    @Test
    void contextLoads() {
    }
}
