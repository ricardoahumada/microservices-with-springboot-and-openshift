---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304502207fa628203f3a59da09e49f3b0baa461b68fcdee122e6dff06006071aa2450018022100b574be380cb420e9af6b8fad43d2d81c19cac83f1db82bb64e89cef1d76233a9
    ReservedCode2: 3045022059adc3ad1f2b3309f9689e6d87555b93aabb4f5e4514eb14a86f33981b1c8942022100fcd1c1b4e8234d0fee1ee3cb9bf12e788b2779197939cfb1644832eb666abab0
---

# Guía de Evolución: De Proyecto Básico a DDD Completo

> **Objetivo**: Transformar el microservicio `afiliado-service` desde una estructura básica hacia una arquitectura DDD completa.

---

## Punto de Partida

El proyecto básico (`mutualidad-platform/afiliado-service`) contiene:

```
src/main/java/com/mutualidad/afiliado/
├── AfiliadoServiceApplication.java
└── controller/
    └── HealthController.java
```

**Estado actual**: Solo la aplicación Spring Boot con un endpoint de salud básico.

---

## Objetivo Final

Estructura DDD completa (`mutualidad-platform-complete/afiliado-service`):

```
src/main/java/com/mutualidad/afiliado/
├── AfiliadoServiceApplication.java
├── api/
│   ├── controller/
│   │   └── AfiliadoController.java
│   └── dto/
│       ├── AfiliadoRequest.java
│       └── AfiliadoResponse.java
├── application/
│   └── service/
│       └── AfiliadoService.java
├── domain/
│   └── model/
│       ├── Afiliado.java
│       ├── DNI.java
│       └── EstadoAfiliado.java
└── infrastructure/
    └── persistence/
        └── AfiliadoJpaRepository.java
```

---

## Evolución Paso a Paso

### FASE 1: Capa de Dominio (El Corazón del Negocio)

> **Principio DDD**: Comenzamos por el dominio porque es el núcleo de la aplicación. Aquí viven las reglas de negocio, independientes de frameworks y tecnología.

#### Paso 1.1: Crear paquete `domain.model`

**Ubicación**: `src/main/java/com/mutualidad/afiliado/domain/model/`

**¿Por qué primero?** El dominio es el centro de DDD. Define el lenguaje ubicuo y las reglas de negocio antes de pensar en persistencia o APIs.

---

#### Paso 1.2: Crear `EstadoAfiliado.java` (Enum)

**Paquete**: `com.mutualidad.afiliado.domain.model`

**¿Por qué?**
- Define los estados posibles de un afiliado: PENDIENTE, ACTIVO, SUSPENDIDO, BAJA
- Es un Value Object simple que limita los valores válidos
- Se usa dentro del Aggregate `Afiliado`

**Orden**: Primero porque `Afiliado` dependerá de este enum.

---

#### Paso 1.3: Crear `DNI.java` (Value Object)

**Paquete**: `com.mutualidad.afiliado.domain.model`

**¿Por qué?**
- Encapsula la validación del DNI español (formato, letra de control)
- Es inmutable: una vez creado, no cambia
- Aporta semántica: no es un simple String, es un DNI con reglas

**Características Value Object**:
- Sin identidad propia (se compara por valor)
- Inmutable
- Auto-validante en construcción

**Orden**: Segundo porque `Afiliado` lo usará como atributo embebido.

---

#### Paso 1.4: Crear `Afiliado.java` (Entity / Aggregate Root)

**Paquete**: `com.mutualidad.afiliado.domain.model`

**¿Por qué?**
- Es la entidad principal del Bounded Context "Gestión de Afiliados"
- Tiene identidad única (ID)
- Contiene reglas de negocio: `activar()`, `darDeBaja()`, `puedeRecibirBeneficios()`
- Usa los Value Objects creados anteriormente (DNI, EstadoAfiliado)

**Como Aggregate Root**:
- Es el punto de entrada para modificaciones del agregado
- Garantiza la consistencia de las invariantes de negocio
- Los cambios de estado se hacen mediante métodos de negocio, no setters directos

**Orden**: Tercero porque depende de `DNI` y `EstadoAfiliado`.

---

### FASE 2: Capa de Infraestructura (Persistencia)

> **Principio DDD**: La infraestructura implementa los detalles técnicos. El dominio no debe conocer cómo se persisten los datos.

#### Paso 2.1: Crear paquete `infrastructure.persistence`

**Ubicación**: `src/main/java/com/mutualidad/afiliado/infrastructure/persistence/`

**¿Por qué separado?** Aísla los detalles de JPA/Hibernate del dominio. Si cambiamos de base de datos, solo afecta esta capa.

---

#### Paso 2.2: Crear `AfiliadoJpaRepository.java` (Repository)

**Paquete**: `com.mutualidad.afiliado.infrastructure.persistence`

**¿Por qué?**
- Extiende `JpaRepository` de Spring Data
- Proporciona operaciones CRUD para `Afiliado`
- Define queries personalizadas: `findByDni()`, `findByEstado()`, etc.

**Orden**: Después del dominio porque depende de la entidad `Afiliado`.

---

### FASE 3: Capa de Aplicación (Casos de Uso)

> **Principio DDD**: Los servicios de aplicación orquestan los casos de uso. No contienen lógica de negocio, solo coordinan.

#### Paso 3.1: Crear paquete `application.service`

**Ubicación**: `src/main/java/com/mutualidad/afiliado/application/service/`

**¿Por qué?** Separa la orquestación de casos de uso del dominio y la API.

---

#### Paso 3.2: Crear `AfiliadoService.java` (Application Service)

**Paquete**: `com.mutualidad.afiliado.application.service`

**¿Por qué?**
- Orquesta los casos de uso: crear afiliado, activar, dar de baja, consultar
- Usa el Repository para persistencia
- Transforma entre DTOs y entidades de dominio
- Maneja transacciones (`@Transactional`)

**Responsabilidades**:
- `crearAfiliado(request)` → Crea y persiste nuevo afiliado
- `obtenerPorId(id)` → Busca afiliado por ID
- `obtenerPorDni(dni)` → Busca afiliado por DNI
- `activarAfiliado(id)` → Activa un afiliado pendiente
- `darDeBaja(id, motivo)` → Procesa baja de afiliado
- `listarActivos()` → Lista afiliados activos

**Orden**: Después de Repository porque lo inyecta como dependencia.

---

### FASE 4: Capa de API (Presentación)

> **Principio DDD**: La capa de API es el adaptador que expone el dominio al mundo exterior. Traduce HTTP a casos de uso.

#### Paso 4.1: Crear paquete `api.dto`

**Ubicación**: `src/main/java/com/mutualidad/afiliado/api/dto/`

**¿Por qué?** Los DTOs desacoplan la representación externa del modelo de dominio interno.

---

#### Paso 4.2: Crear `AfiliadoRequest.java` (DTO de Entrada)

**Paquete**: `com.mutualidad.afiliado.api.dto`

**¿Por qué?**
- Representa los datos que envía el cliente para crear/actualizar afiliados
- Contiene validaciones de entrada (`@NotBlank`, `@Email`, etc.)
- Es independiente de la entidad de dominio

**Orden**: Antes del Controller porque este lo usará.

---

#### Paso 4.3: Crear `AfiliadoResponse.java` (DTO de Salida)

**Paquete**: `com.mutualidad.afiliado.api.dto`

**¿Por qué?**
- Representa los datos que devuelve la API
- Puede incluir campos calculados o excluir datos sensibles
- Desacopla la estructura de respuesta del modelo interno

**Orden**: Junto con Request, antes del Controller.

---

#### Paso 4.4: Crear paquete `api.controller`

**Ubicación**: `src/main/java/com/mutualidad/afiliado/api/controller/`

---

#### Paso 4.5: Crear `AfiliadoController.java` (REST Controller)

**Paquete**: `com.mutualidad.afiliado.api.controller`

**¿Por qué?**
- Expone endpoints REST: GET, POST, PUT, DELETE
- Transforma Request/Response HTTP a llamadas del Application Service
- Maneja códigos de estado HTTP apropiados

**Endpoints típicos**:
- `POST /api/afiliados` → Crear afiliado
- `GET /api/afiliados/{id}` → Obtener por ID
- `GET /api/afiliados/dni/{dni}` → Obtener por DNI
- `PUT /api/afiliados/{id}/activar` → Activar afiliado
- `DELETE /api/afiliados/{id}` → Dar de baja

**Orden**: Último de la producción porque depende de DTOs y Service.

---

### FASE 5: Tests

> **Buenas prácticas**: Los tests validan que cada capa funciona correctamente de forma aislada.

#### Paso 5.1: Crear `DNITest.java` (Test Unitario)

**Paquete**: `com.mutualidad.afiliado.domain.model` (en src/test)

**¿Por qué?**
- Valida las reglas de negocio del Value Object DNI
- Prueba casos válidos e inválidos
- Es un test unitario puro, sin dependencias de Spring

**Orden**: Se puede crear junto con `DNI.java` (TDD).

---

#### Paso 5.2: Crear `AfiliadoServiceApplicationTests.java`

**Paquete**: `com.mutualidad.afiliado` (en src/test)

**¿Por qué?**
- Test de integración que verifica que la aplicación arranca correctamente
- Valida la configuración de Spring Boot

---

## Resumen del Orden de Creación

| Orden | Capa | Clase | Justificación |
|-------|------|-------|---------------|
| 1 | Domain | `EstadoAfiliado.java` | Enum base, sin dependencias |
| 2 | Domain | `DNI.java` | Value Object, usado por Afiliado |
| 3 | Domain | `Afiliado.java` | Aggregate Root, usa DNI y Estado |
| 4 | Infrastructure | `AfiliadoJpaRepository.java` | Persiste Afiliado |
| 5 | Application | `AfiliadoService.java` | Orquesta casos de uso |
| 6 | API | `AfiliadoRequest.java` | DTO entrada para Controller |
| 7 | API | `AfiliadoResponse.java` | DTO salida para Controller |
| 8 | API | `AfiliadoController.java` | Expone REST API |
| 9 | Test | `DNITest.java` | Valida reglas de DNI |
| 10 | Test | `AfiliadoServiceApplicationTests.java` | Test de integración |

---

## Diagrama de Dependencias

```
┌─────────────────────────────────────────────────────────────┐
│                         API Layer                           │
│  ┌─────────────────┐    ┌─────────────┐  ┌───────────────┐  │
│  │AfiliadoController│───▶│AfiliadoRequest│ │AfiliadoResponse│ │
│  └────────┬────────┘    └─────────────┘  └───────────────┘  │
│           │                                                  │
└───────────┼──────────────────────────────────────────────────┘
            │ usa
            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Application Layer                         │
│           ┌──────────────────┐                               │
│           │  AfiliadoService │                               │
│           └────────┬─────────┘                               │
│                    │                                         │
└────────────────────┼─────────────────────────────────────────┘
                     │ usa
          ┌──────────┴──────────┐
          ▼                     ▼
┌──────────────────┐  ┌─────────────────────────────────────────┐
│Infrastructure    │  │              Domain Layer                │
│ Layer            │  │  ┌──────────┐  ┌─────┐  ┌─────────────┐ │
│┌────────────────┐│  │  │ Afiliado │──│ DNI │  │EstadoAfiliado│ │
││AfiliadoJpa     ││  │  │(Aggregate)│  │(VO) │  │   (Enum)    │ │
││Repository      ││  │  └──────────┘  └─────┘  └─────────────┘ │
│└────────────────┘│  │                                         │
└──────────────────┘  └─────────────────────────────────────────┘
```

---

## Principios Aplicados

### 1. **Separación de Responsabilidades**
Cada capa tiene una responsabilidad clara y no conoce detalles de las otras.

### 2. **Dependency Inversion**
Las capas superiores dependen de abstracciones, no de implementaciones concretas.

### 3. **Domain-Driven Design**
- El dominio es el centro de la arquitectura
- Value Objects para conceptos sin identidad
- Entities para conceptos con identidad
- Aggregate Roots para garantizar consistencia

### 4. **Clean Architecture**
- Dominio independiente de frameworks
- Infraestructura como detalle de implementación
- API como adaptador externo

---

## Siguiente Paso

Una vez completada esta evolución, el microservicio `afiliado-service` estará listo para:

1. **Integrarse con otros microservicios** (beneficio-service, notificacion-service)
2. **Añadir Domain Events** para comunicación asíncrona
3. **Implementar patrones avanzados** como CQRS o Event Sourcing
4. **Desplegar en Kubernetes/OpenShift** con las configuraciones del Módulo 7
