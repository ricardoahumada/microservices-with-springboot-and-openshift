---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 30460221008435655109219cb4f56d0498f6627427dbe697f69592b50b5ac25b5647b1f3c7022100fb36bec94f18c4e99d75500e5c52aeb47e52db726121248c724d1623258c8795
    ReservedCode2: 3045022100cae5bcb7d3543d115cf0cdcb60501b3e90894cfa0fffd76e0e7729e310118e760220557c9e7ccd86d082a94649e9c1072886651a0d2a1de7e7699fbb9558ebfd9c54
---

# Evolución: beneficio-service

## De mutualidad-platform-base a mutualidad-platform

### Estructura Base (2 clases)
```
beneficio-service/
└── src/main/java/com/mutualidad/beneficio/
    ├── BeneficioServiceApplication.java
    └── controller/
        └── HealthController.java
```

### Estructura Completa (12 clases)
```
beneficio-service/
└── src/main/java/com/mutualidad/beneficio/
    ├── BeneficioServiceApplication.java
    ├── api/
    │   ├── controller/
    │   │   └── BeneficioController.java
    │   └── dto/
    │       ├── BeneficioRequest.java
    │       └── BeneficioResponse.java
    ├── application/
    │   └── service/
    │       ├── BeneficioService.java
    │       └── SolicitudService.java
    ├── domain/
    │   └── model/
    │       ├── Beneficio.java
    │       ├── Solicitud.java
    │       ├── TipoBeneficio.java
    │       └── EstadoSolicitud.java
    └── infrastructure/
        └── persistence/
            ├── BeneficioJpaRepository.java
            └── SolicitudJpaRepository.java
```

---

## Clases a Añadir

### 1. domain/ (Modelos de Dominio)

| Clase | Descripción |
|-------|-------------|
| `Beneficio.java` | Entidad principal con id, nombre, descripción, tipo |
| `Solicitud.java` | Solicitud de beneficio por un afiliado |
| `TipoBeneficio.java` | Enum: SALUD, EDUCACION, VIVIENDA, etc. |
| `EstadoSolicitud.java` | Enum: PENDIENTE, APROBADA, RECHAZADA |

### 2. application/ (Servicios)

| Clase | Descripción |
|-------|-------------|
| `BeneficioService.java` | CRUD de beneficios |
| `SolicitudService.java` | Gestión de solicitudes |

### 3. infrastructure/ (Persistencia)

| Clase | Descripción |
|-------|-------------|
| `BeneficioJpaRepository.java` | Repositorio JPA para Beneficio |
| `SolicitudJpaRepository.java` | Repositorio JPA para Solicitud |

### 4. api/ (Controladores y DTOs)

| Clase | Descripción |
|-------|-------------|
| `BeneficioController.java` | Endpoints REST |
| `BeneficioRequest.java` | DTO de entrada |
| `BeneficioResponse.java` | DTO de salida |

### 5. test/ (Tests)

| Clase | Descripción |
|-------|-------------|
| `BeneficioServiceApplicationTests.java` | Test de contexto Spring |

---

## Pasos de Implementación

### Paso 1: Crear estructura de paquetes
```
mkdir -p src/main/java/com/mutualidad/beneficio/{api/{controller,dto},application/service,domain/model,infrastructure/persistence}
mkdir -p src/test/java/com/mutualidad/beneficio
```

### Paso 2: Copiar clases de domain/
Copiar: `Beneficio.java`, `Solicitud.java`, `TipoBeneficio.java`, `EstadoSolicitud.java`

### Paso 3: Copiar clases de infrastructure/
Copiar: `BeneficioJpaRepository.java`, `SolicitudJpaRepository.java`

### Paso 4: Copiar clases de application/
Copiar: `BeneficioService.java`, `SolicitudService.java`

### Paso 5: Copiar clases de api/
Copiar: `BeneficioController.java`, `BeneficioRequest.java`, `BeneficioResponse.java`

### Paso 6: Eliminar HealthController.java
Ya no es necesario con el controller real.

---

## Verificación

```bash
cd beneficio-service
mvn clean compile
mvn spring-boot:run
```

Probar endpoint:
```bash
curl http://localhost:8082/api/beneficios
```
